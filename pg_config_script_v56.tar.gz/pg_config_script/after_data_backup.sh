#!/bin/sh

# After data hot backup, using this sample script.
# before using this script, have to set up DB environments


# OS USER
PGUSER = postgres

# Engine Home
PGHOME=/postgres/15

# DB Cluster Name
CLUSTER_NAME = ?

# DB PORT
PGPORT = 5432

#LOG DESTINATION
BACKUP_LOG_DIR=/tmp/backup_log
BACKUP_LOG_FILE=$BACKUP_LOG_DIR/after_data_backup_`date +%Y%m%d%H%M`.log


# After backup execute
if [ "$PGUSER" == "postgres" ]; then
    DATABASE_NAME='postgres'
elif [ "$PGUSER" == "enterprisedb" ]; then
    DATABASE_NAME='edb'
else
    exit 1;
fi

su - $PGUSER -c "$PGHOME/bin/psql -h /tmp -c \"select pg_stop_backup();\" $DATABASE_NAME">> $BACKUP_LOG_FILE"
date >> $BACKUP_LOG_FILE
echo "end backup ..." >> $BACKUP_LOG_FILE
