#!/bin/sh
 
if [ $# -ne 1 ]; then
    echo "Usage: $0 DATABASE_NAME"
    exit;
fi;
 
WORKDB=$1;
WORKDB=`echo ${WORKDB} | tr [A-Z] [a-z]`;
export PGHOST=/tmp
current_user=`whoami`
dfpw="new1234!"
 
echo "===> [1][Receive WORKDB name is \"${WORKDB}\" & PGHOST is \"${PGHOST}]\""
echo "===> [1][Current_user is \"${current_user}\" & dfpw is \"${dfpw}\""
 
##------------------------------------------------------------------------------------------------------------
##-- 1. Database name  ${WORKDB}
##------------------------------------------------------------------------------------------------------------
psql -q -c "CREATE DATABASE ${WORKDB} ENCODING = 'UTF8' template = template0 LC_COLLATE = 'C' LC_CTYPE = 'C'"
if [ $? -ne 0 ]; then
    date
    echo "===> [1][Already exists ${WORKDB} Database !]"
else
    date
    echo "[1][CREATE ${WORKDB} DATABASE Success!]"
fi
 
psql -q -c "ALTER USER ${current_user} PASSWORD '${dfpw}';"
if [ $? -ne 0 ]; then
    date
    echo "===>[1][There is no ${current_user} role or failed query execute !]"
else
    date
    echo "[1][ALTER ROLE PASSWORD ${current_user} Success!]"
fi