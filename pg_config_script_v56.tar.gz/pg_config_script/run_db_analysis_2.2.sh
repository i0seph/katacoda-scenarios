#!/bin/bash

# 마지막 수정일: 2020.01.03
# Analysis Tool for PostgreSQL v2.1
# Created by OpenSource Business Team, kt ds.
# Used to determine system information with a single command

# set variable
#DBNAME=$1
PGDATA=`echo $PGDATA`
DB_VERSION=`cat $PGDATA/PG_VERSION`
DATE=`date +%Y%m%d%H%M`
SCRIPT_VSERSION=`echo 2.1`
CLUSTER=`echo ${PGDATA} | cut -d '/' -f 3`
MEM=`cat /proc/meminfo | grep MemTotal | sed -e 's/[^0-9]//g'`
echo "DB Analysis Tool for PostgreSQL/EDB PAS ${SCRIPT_VSERSION}"
echo "Copyright 2018 OpenSource Business Team, kt ds."
echo "----------------------------------------"

echo -n "input DB name: "
read DBNAME
echo -n "Please input 'enterprisedb' or 'postgres' account password: "
read PGPW
#DBNAME=`echo ${DBNAME} | tr [A-Z] [a-z]`;
#PGPW=`echo ${PGPW} | tr [A-Z] [a-z]`;
if [ -z $DBNAME ]; then
    echo "ERROR! Please input DB name."
    exit;
    exit;
elif [ -z $PGPW ]; then
    echo "ERROR! Please input password"
    exit;
fi;
CHECK=`PGPASSWORD=${PGPW} psql -X -t -c "select 1;" ${DBNAME} 2>&1 | cut -d ':' -f 2`
if [ ${CHECK} = "FATAL" ]; then
echo "ERROR! Please check your DB name or password"
exit;
else
echo "----------------------------------------"
fi;	

cat > /tmp/tztz.$DATE.py  <<EOFF
#!/usr/bin/python
import sys
import re

keycount = {};

for i in re.split("\\|", sys.argv[1]):
        keycount[i] = 0;

try:
    while True:
        s = sys.stdin.readline();
        if not s:
                break;
        r = re.search(sys.argv[1],  s.strip());
        if r:
                keycount[r.group(0)] += 1;
except KeyboardInterrupt:
    sys.stdout.flush()
    pass
for k, v in keycount.items():
 print("%d : %s" % (v,k))
EOFF
chmod 777 /tmp/tztz.$DATE.py


# you can edit this to suit your own output location
ofile=./analysis_`hostname`_$DATE.html
# error file output, change to file location for debugging
errfile=/dev/null

#echo "Removing old system info file ($ofile)"
export LC_ALL=C

# OS version check
ver=$(uname -r | awk -F- '{print $1}')

# find command
find_sbin_cmd() {
    for base in / /usr/ /usr/local; do
        if [ -e $base/sbin/$1 ]; then
            echo $base/sbin/$1
            exit
        fi
    done
}
FDISK=`which fdisk 2>/dev/null`
LSUSB=`which lsusb 2>/dev/null`
LSPCI=`which lspci 2>/dev/null`
[ -z "$FDISK" ] && FDISK=`find_sbin_cmd fdisk`
[ -z "$LSUSB" ] && LSUSB=`find_sbin_cmd lsusb`
[ -z "$LSPCI" ] && LSPCI=`find_sbin_cmd lspci`

# start HTML
echo "Generating system stats, please wait ... (can take a few minutes on slow systems)"
echo "File generated at $ofile on `date` (FORMAT: analysis_hostname_date.html)"

cat > $ofile <<EOFF
<HTML>
<head>
<meta content="text/html; charset=UTF-8" http-equiv="content-type" />
<title>DB Analysis Info.</title>
<style type="text/css">
table { border-collapse:collapse; }
th, TD { border:1px solid #000000; }
</style>
</head>
<BODY>
<H1>DB(Postgres/EDB PAS) Analysis Information</H1>
EOFF

echo "Report generated on `date`. <br>">>$ofile 2>&1 
echo "Script Version $SCRIPT_VSERSION">>$ofile 2>&1 

############ System Information ############

echo "<TABLE><TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">System Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "****** Status *******"
echo "System Information...15%"

echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Hostname</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>`hostname`</PRE></TD></TR>">>$ofile 2>&1

echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Version</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
cat /etc/redhat-release >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Kernel</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
uname -r >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">CPU Model</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
grep "model name" /proc/cpuinfo | head -1 >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">CPU Specification</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
lscpu  >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Memory</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
echo "${MEM}KB" >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Filesystem</FONT></TD>" >>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
echo "<b>volume usage(%)</b>" >>$ofile 2>&1
df -h >>$ofile 2>&1

echo "<b>inode usage(%)</b>" >>$ofile 2>&1
df -i >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ Network Information ############

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Network Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "Network config...20%"
#echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Firewall</FONT></TD>">>$ofile 2>&1
#grep -v "^#" /etc/firewall | grep -v "^$" >>$ofile 2>&1

echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Interface Settings</FONT></TD>" >>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
/sbin/ifconfig  >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Hosts</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
cat /etc/hosts >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ Server Status ############

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Server Status Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Processor/RAM Usage</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
top -b -n 1 | sed -n '1,20p'  >>$ofile 2>&1

free -m >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Running Postgres Processes</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
ps -eHf | grep "/bin/postgres\|/bin/edb-postgres\|process\|VACUUM" | grep -v "grep" >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Idle in transaction Processes</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
if [ "${DB_VERSION}" == "8.4" -o "${DB_VERSION}" == "9.0" -o "${DB_VERSION}" == "9.1" ]; then 
ps -eHf | grep "idle in transaction" | grep -v "grep" >>$ofile 2>&1 
else
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where state = 'idle in transaction';" ${DBNAME} >>$ofile 2>&1
fi;
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Long running transaction Processes(1 days)</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
if [ "${DB_VERSION}" == "8.4" -o "${DB_VERSION}" == "9.0" -o "${DB_VERSION}" == "9.1" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select now(), * from pg_stat_activity where xact_start < now() - interval '1 days';" ${DBNAME} >>$ofile 2>&1 
else
PGPASSWORD=${PGPW} psql -X -c "select now(), * from pg_stat_activity where state = 'active' and xact_start < now() - interval '1 days';" ${DBNAME} >>$ofile 2>&1
fi;
echo "</PRE></TD></TR>">>$ofile 2>&1

# echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Running Services</FONT></TD>">>$ofile 2>&1
# service --status-all 2>>$errfile | grep -e 'running\|cours' | grep -v 'not running' >>$ofile 2>&1


############ DB Basic Info ############
echo "DB Basic Info...35%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">DB Basic Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
HOME_DIR=`echo $HOME`
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Version</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "select version();" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">DB List</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "\l+" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Directory Info</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
echo  $HOME_DIR  >>$ofile 2>&1
echo  $PGDATA  >>$ofile 2>&1

if [ "${DB_VERSION}" == "10" -o "${DB_VERSION}" == "11" -o "${DB_VERSION}" == "12" -o "${DB_VERSION}" == "13" ]; then 
ls -l /pg_wal /archive  >>$ofile 2>&1
else
ls -l /pg_xlog /archive  >>$ofile 2>&1
fi;

echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">TableSpace Info.</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
if [ "${DB_VERSION}" == "8.4" ]; then 
PGPASSWORD=${PGPW} psql -X -c "SELECT spcname, pg_get_userbyid(spcowner) AS owner, CASE WHEN length(spclocation) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') ELSE spclocation END AS spclocation, spcacl,  pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "9.0" -o  "${DB_VERSION}" == "9.1" ]; then
PGPASSWORD=${PGPW} psql -X -c "SELECT spcname, pg_get_userbyid(spcowner) AS owner, CASE WHEN length(spclocation) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') ELSE spclocation END AS spclocation, spcacl, spcoptions , pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;" ${DBNAME} >>$ofile 2>&1
elif [ "$DB_VERSION" == "9.2" -o "$DB_VERSION" == "9.3" -o "$DB_VERSION" == "9.4" -o "$DB_VERSION" == "9.5" -o "$DB_VERSION" == "9.6" -o "$DB_VERSION" == "10" -o "$DB_VERSION" == "11" -o "$DB_VERSION" == "12" -o "$DB_VERSION" == "13" ]; then
PGPASSWORD=${PGPW} psql -X -c "SELECT spcname, pg_get_userbyid(spcowner) AS owner, CASE WHEN length(pg_tablespace_location(oid)) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') ELSE pg_tablespace_location(oid) END AS spclocation, spcacl, pg_tablespace_location(oid) as spcoptions , pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;" ${DBNAME} >>$ofile 2>&1
else
echo "can't find TableSpace information. check your DB version!" >>$ofile 2>&1
fi;
echo "</PRE></TD></TR>">>$ofile 2>&1
############ Connection & Mem Info ############

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Connection & Mem Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Existing Value</b></FONT></TD></TD>">>$ofile
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">max_connections</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">less than 200</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
MC=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::int from pg_settings where name='max_connections';" ${DBNAME}`
if [ ${MC} -le 200 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show max_connections;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show max_connections;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">superuser_reserved_connections</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">3</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "3" != `PGPASSWORD=${PGPW} psql -X -t -c "show superuser_reserved_connections" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show superuser_reserved_connections;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show superuser_reserved_connections;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

SB=`expr $MEM*0.25|bc |cut -d '.' -f 1`
SBG=`expr $SB*0.50|bc |cut -d '.' -f 1`
LSB=`expr $SB-$SBG|bc`
GSB=`expr $SB+$SBG|bc`
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\" title=\"physical Memory * 0.25\">shared_buffers</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">${SB}KB<br>(physical Memory * 0.25)</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
SBC=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::int*8 from pg_settings where name='shared_buffers';" ${DBNAME}`
if [ ${SBC} -ge ${LSB} -a ${SBC} -le ${GSB} ]; then 
echo "<FONT>${SBC}KB" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>${SBC}KB" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

WMM=`expr $MEM-$MEM*0.25|bc -l | cut -d '.' -f 1`
WM=$(($WMM/$MC))
WMC=`PGPASSWORD=${PGPW} psql -X -t -c "select setting from pg_settings where name='work_mem';" ${DBNAME}`
WMG=`expr $WM*0.50|bc |cut -d '.' -f 1`
LWM=`expr $WM-$WMG|bc`
GWM=`expr $WM+$WMG|bc`
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\" title=\"(physical Memory -Shared buffer)/connection\">work_mem</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">${WM}KB<br>(physical Memory-Shared buffer)/connection)</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ ${WMC} -ge ${LWM} -a ${WMC} -le ${GWM} ]; then 
echo "<FONT>${WMC}KB" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>${WMC}KB" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

MWM=`PGPASSWORD=${PGPW} psql -X -t -c "select setting from pg_settings where name='maintenance_work_mem'"`;
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\" title=\"work_mem * 1.5\">maintenance_work_mem</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">512MB</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ ${MWM} -ge 51200 -a ${MWM} -le 524288 ]; then 
echo "<FONT>${MWM}KB" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>${MWM}KB" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

EDBDT=`PGPASSWORD=${PGPW} psql -X -t -c "select setting from pg_settings where name='edb_dynatune';"`
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">edb_dynatune</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">99</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ ${EDBDT} -le 65 ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show edb_dynatune;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show edb_dynatune;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

############ WAL Info ############
echo "WAL Info...55%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">WAL Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Existing Value</b></FONT></TD></TD>">>$ofile
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">Transaction log size</FONT></TD>">>$ofile 
#echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">32~128</FONT></TD>">>$ofile 2>&1
#echo "<TD valign=top>">>$ofile 2>&1
if [ "${DB_VERSION}" == "9.5"  -o "${DB_VERSION}" == "9.6"  -o "${DB_VERSION}" == "10" -o "${DB_VERSION}" == "11"  -o "${DB_VERSION}" == "12"  -o "${DB_VERSION}" == "13" ]; then 
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">max_wal_size: 2GB<br>min_wal_size: 2GB</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
echo "max_wal_size:" >>$ofile 2>&1
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show max_wal_size;" ${DBNAME}`<br>" >>$ofile 2>&1
echo "min_wal_size:" >>$ofile 2>&1
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show min_wal_size;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">32~128</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
CPS=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::int from pg_settings where name='checkpoint_segments';" ${DBNAME}`
if [ ${CPS} -ge 32 -a ${CPS} -le 128 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_segments;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_segments;" ${DBNAME}`" >>$ofile 2>&1
fi;
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">checkpoint_timeout</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">5min~15min</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
CPT=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::int from pg_settings where name='checkpoint_timeout';" ${DBNAME}`
if [ ${CPT} -ge 300 -a ${CPT} -le 900 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_timeout;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_timeout;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">checkpoint_completion_target</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">0.5~0.9</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
CCT=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::float*10 from pg_settings where name='checkpoint_completion_target';" ${DBNAME}`
if [ ${CCT} -ge 5 -a ${CCT} -le 9 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_completion_target;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_completion_target;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">wal_buffers</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">16MB</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "16MB" != `PGPASSWORD=${PGPW} psql -X -t -c "show wal_buffers" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_buffers;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_buffers;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
if [ "${DB_VERSION}" != "8.4" ]; then
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">wal_level</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">logical</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "minimal" = `PGPASSWORD=${PGPW} psql -X -t -c "show wal_level" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_level;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_level;" ${DBNAME}`" >>$ofile 2>&1
fi;
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">fsync</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "on" != `PGPASSWORD=${PGPW} psql -X -t -c "show fsync" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show fsync;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show fsync;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">synchronous_commit</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "on" != `PGPASSWORD=${PGPW} psql -X -t -c "show Synchronous_commit" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show Synchronous_commit;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show Synchronous_commit;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">wal_sync_method</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">fdatasync</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "fdatasync" != `PGPASSWORD=${PGPW} psql -X -t -c "show wal_sync_method" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_sync_method;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_sync_method;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">archive_mode</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "on" != `PGPASSWORD=${PGPW} psql -X -t -c "show archive_mode" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show archive_mode;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show archive_mode;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

TMPC=`echo "dd conv=fdatasync bs=256k if=%p of=/archive/temp/%f && \\\mv -f /archive/temp/%f /archive/${CLUSTER}"`
TMPC2=`PGPASSWORD=${PGPW} psql -X -t -c "show archive_command;" ${DBNAME} |sed 's/^ //'`
echo "<TR><TD valign=top TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">archive_command</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "$TMPC" = "$TMPC2" ]; then 
echo "<FONT>${TMPC2}" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>${TMPC2}<br>" >>$ofile 2>&1
echo "<A href='http://opensource.kt.com/db/-/wiki/Main/archive+command'><pre>More Detail. Click Here!!</pre></a>" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

############ Planner Info ############
echo "Planner Info...70%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Planner Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Existing Value</b></FONT></TD></TD>">>$ofile
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">random_page_cost</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">4</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "4" != `PGPASSWORD=${PGPW} psql -X -t -c "show random_page_cost;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show random_page_cost;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show random_page_cost" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">default_statistics_target</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">100</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1

if [ "100" != `PGPASSWORD=${PGPW} psql -X -t -c "show default_statistics_target;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show default_statistics_target;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show default_statistics_target" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Changed Settings: Need to reset</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "select name, setting,short_desc from pg_settings where setting<>reset_val and name like 'enable_%';" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ AutoVaccum Info ############

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">AutoVaccum Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Existing Value</b></FONT></TD></TD>">>$ofile
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">autovacuum</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "off" = `PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">autovacuum_max_workers</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">5</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "5" != `PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum_max_workers;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum_max_workers;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum_max_workers;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
# analyze 대상 객체 출력
PGPASSWORD=${PGPW} psql -X -t -c "select 'analyze ' || a.oid::regclass || ';' from pg_class a left join 
(select starelid, sum(stawidth) as rowsize from pg_statistic group by starelid) b 
on (a.oid = b.starelid) 
where a.relkind in ('r','m') and a.relname <> 'pg_statistic' and (a.reltuples::numeric * b.rowsize) is null;" ${DBNAME} > analyze_list.sql
# analyze 수행
PGPASSWORD=${PGPW} psql -X -f analyze_list.sql ${DBNAME} > analyze_list.log
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Vacuum & autovacuum Information: May need to vacuum </FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT schemaname,
       a.oid::regclass as table_name,
       age(a.relfrozenxid),
       pg_size_pretty(pg_relation_size(relid)) AS relation_size,
       coalesce(last_vacuum::text, 'Never') as last_vacuum,
       coalesce(last_autovacuum::text, 'Never') as last_autovacuum,
       coalesce(last_analyze::text, 'Never') as last_analyze,
       coalesce(last_autoanalyze::text, 'Never') as last_autoanalyze
FROM pg_class a
LEFT JOIN (select relname,relid,last_autovacuum,last_vacuum,last_autoanalyze,last_analyze,schemaname
        from   pg_stat_all_tables
        where  pg_relation_size(relid) > 104857600 ) b ON a.oid = b.relid 
LEFT JOIN (SELECT starelid, sum(stawidth) AS stawidth
		   FROM pg_statistic
		   GROUP BY starelid) c ON a.oid = c.starelid 
WHERE relkind IN ('r', 'm')
AND a.relname <> 'pg_statistic'
AND relpages > 0
and ((( last_autovacuum IS NULL OR last_autovacuum < now() - interval '3 month' ) AND ( last_vacuum IS NULL  OR last_vacuum < now() - interval '3 month' ))
   OR  (( last_autoanalyze IS NULL OR last_analyze < now() - interval '3 month') AND (last_analyze IS NULL OR last_analyze < now() - interval '3 month' )))
and b.schemaname not in ('pg_toast', 'information_schema', 'pg_catalog', 'sys')
ORDER BY 2 desc;" ${DBNAME} >>$ofile 2>&1
echo "<FONT><A href='http://opensource.kt.com/db/-/wiki/Main/Autovacuum+Information'>More Detail. Click Here!!</a></FONT>">>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

# Aging table list
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Aging table list: May need to vacuum</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "select relname as table_name, age(relfrozenxid) from pg_class where age(relfrozenxid) > 200000000 and relkind in ('r','t','m') order by 2 desc;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ Statistics Info ############
echo "Statistics Info...80%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Statistics Information</b></FONT></TD></TR>">>$ofile 2>&1
#echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Cache Hit Rate</FONT></TD>">>$ofile 2>&1
#PGPASSWORD=${PGPW} psql -X -c "SELECT datname,   round(blks_hit*100/(blks_hit+blks_read), 2) AS cache_hit_ratio FROM pg_stat_database WHERE blks_read > 0;" ${DBNAME} >>$ofile 2>&1

#echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Table Cache Hit Rate</FONT></TD>">>$ofile 2>&1
#PGPASSWORD=${PGPW} psql -X -c "SELECT relname,  round(heap_blks_hit*100/(heap_blks_hit+heap_blks_read), 2)  AS cache_hit_ratio FROM pg_statio_user_tables WHERE heap_blks_read > 0 ORDER BY cache_hit_ratio;" ${DBNAME} >>$ofile 2>&1

# DB별 age
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Database Age</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT datname as database, age(datfrozenxid) from pg_database;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Top busy table info(50)</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT n.nspname as schema_name, c.relname as table_name,
           pg_stat_get_live_tuples(c.oid) as rows,
           pg_stat_get_numscans(c.oid) as seqscan,
           pg_stat_get_tuples_returned(c.oid) as returned_rows,
           CASE WHEN coalesce(pg_stat_get_numscans(c.oid),0) = 0
           THEN 0
           ELSE round(coalesce(pg_stat_get_tuples_returned(c.oid),0)/pg_stat_get_numscans(c.oid),1) END AS returned_rows_average,
           sum(coalesce(pg_stat_get_numscans(i.indexrelid),0)) as idxscan, 
           CASE WHEN  pg_stat_get_blocks_fetched(c.oid) = 0
           THEN 0
           ELSE round(((pg_stat_get_blocks_hit(c.oid) * 1.0) / pg_stat_get_blocks_fetched(c.oid)) * 100,2) END AS tab_hit,
           CASE WHEN sum(coalesce(pg_stat_get_blocks_fetched(i.indexrelid),0)) = 0
           THEN 0
           ELSE round(((sum(coalesce(pg_stat_get_blocks_hit(i.indexrelid),0)) * 1.0) / sum(coalesce(pg_stat_get_blocks_fetched(i.indexrelid),0))) * 100, 2) END AS idx_hit
FROM pg_class c
  LEFT JOIN pg_index i ON c.oid = i.indrelid
  LEFT JOIN pg_namespace n ON n.oid = c.relnamespace 
WHERE c.relkind = 'r' and n.nspname not in ('pg_catalog','information_schema','pg_toast','sys','pgagent')
GROUP BY c.oid, n.nspname, c.relname
ORDER BY seqscan desc, rows desc limit 50;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Bloat table: Need to vacuum</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT b.schemaname,
       a.oid::regclass as table_name,
       age(a.relfrozenxid),
       a.relpages * 8::int8 AS relation_size,
       ceil((b.n_live_tup * c.stawidth) * 1.0 / 8192) * 8 AS actual_size,
       int8((a.relpages * 8::int8) / (ceil((b.n_live_tup * c.stawidth) * 1.0 / 8192) * 8)) AS bloating_ratio,
       last_vacuum,
       last_autovacuum
FROM pg_class a
LEFT JOIN pg_stat_all_tables b ON a.oid = b.relid
LEFT JOIN (SELECT starelid, sum(stawidth) AS stawidth FROM pg_statistic GROUP BY starelid) c ON a.oid = c.starelid
WHERE relkind IN ('r', 'm')
AND a.relname <> 'pg_statistic'
AND relpages > 0
and b.n_live_tup > 0
AND int8((a.relpages * 8::int8) / (ceil((b.n_live_tup * c.stawidth) * 1.0 / 8192) * 8)) > 5
ORDER BY 2 desc;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Bloat index: Need to reindex</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT c.schemaname,
       c.relname as table_name,
       a.oid::regclass as index_name,
       a.relpages * 8192::int8 AS index_size,
       ceil(b.keywidth * 1.0 * c.n_live_tup / 7373) * 8192 + 8192 AS actual_size,
       round((a.relpages * 8192::int8 * 1.0) / (ceil(b.keywidth * 1.0 * c.n_live_tup / 7373) * 8192 + 8192), 0) AS bloating_ratio 
FROM pg_class a,(SELECT a.indexrelid, a.indrelid, sum(b.stawidth + 1) + 9 AS keywidth
				 FROM pg_index a, pg_statistic b
				 WHERE a.indrelid = b.starelid
				 AND arraycontains(string_to_array(a.indkey::text, ' '), array[b.staattnum::text])
				 GROUP BY a.indexrelid, a.indrelid) b,
     pg_stat_all_tables c
WHERE a.oid = b.indexrelid
AND b.indrelid = c.relid
AND round((a.relpages * 8192::int8 * 1.0) / (ceil(b.keywidth * 1.0 * c.n_live_tup / 7373) * 8192 + 8192), 0) > 2 
order by 6 desc;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Unused Index: Need to check</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT n.nspname AS schema_name, c.relname as table_name, i.relname AS index_name, pg_indexes_size(indexrelid) as index_size, pg_stat_get_blocks_fetched(i.oid) AS idx_fetched, pg_stat_get_blocks_hit(i.oid) AS idx_blks_hit
   FROM pg_class c
   JOIN pg_index x ON c.oid = x.indrelid
   JOIN pg_class i ON i.oid = x.indexrelid
   LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE c.relkind =  ANY (ARRAY['r'::"char", 't'::"char"])
  and n.nspname not in ('pg_catalog','information_schema','pg_toast','sys','pgagent') and pg_stat_get_blocks_fetched(i.oid) = 0;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Duplicate indexes: Need to check </FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "with ttt as (
SELECT indrelid, indexrelid::regclass AS idx,
               (indrelid::text ||E'\n'|| indclass::text ||E'\n'|| indkey::text ||E'\n'|| coalesce(indexprs::text, '')||E'\n' || coalesce(indpred::text, '')) AS KEY
        FROM   pg_index)
        select ttt.indrelid::regclass as table_name, array_to_string(array_agg(ttt.idx),',') as index_name from ttt  GROUP BY KEY, table_name
HAVING count(*)>1" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">LOCK Info</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
if [ "${DB_VERSION}" == "13" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type='Lock';" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "12" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type='Lock';" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "11" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type='Lock';" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "10" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type is not null and backend_xid is not null;" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "9.6" ]; then
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type is not null;" ${DBNAME} >>$ofile 2>&1
else
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where waiting='t';" ${DBNAME} >>$ofile 2>&1
fi;
echo "</PRE></TD></TR>">>$ofile 2>&1
############ Log Info ############
echo "Log Info...90%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Log Information</b></FONT></TD></TR>">>$ofile 2>&1

if [ "${DB_VERSION}" == "10" -o "${DB_VERSION}" == "11" -o "${DB_VERSION}" == "12" -o "${DB_VERSION}" == "13" ]; then 
SLOWCOUNT=`find $PGDATA/log/ -type f -mtime -1 | xargs grep duration | egrep -v 'BEGIN|COMMIT|ROLLBACK' | cut -d ' ' -f 9 | sort -rn | wc -l`
else
SLOWCOUNT=`find $PGDATA/pg_log/ -type f -mtime -1 | xargs grep duration | egrep -v 'BEGIN|COMMIT|ROLLBACK' | cut -d ' ' -f 9 | sort -rn | wc -l`
fi;

echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Changed Settings: Need to reset</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "select name, setting,short_desc from pg_settings where setting<>reset_val and name like 'log_rotation%';" ${DBNAME} >>$ofile 2>&1
SLOWTIME=`PGPASSWORD=${PGPW} psql -X -t -c "show log_min_duration_statement"`
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">ERROR Scan Information</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
if [ "${DB_VERSION}" == "10" -o "${DB_VERSION}" == "11" -o "${DB_VERSION}" == "12" -o "${DB_VERSION}" == "13" ]; then 
find $PGDATA/log/ -mtime -90 -name "*.log" -exec egrep "ERROR:|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed" {} \; | /tmp/tztz.$DATE.py  "ERROR|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed">>$ofile 2>&1
else
find $PGDATA/pg_log/ -mtime -90 -name "*.log" -exec egrep "ERROR:|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed" {} \; | /tmp/tztz.$DATE.py  "ERROR|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed">>$ofile 2>&1
fi;
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">slow query running time in 24 hours</FONT></TD>" >>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
echo "Slow query time is${SLOWTIME}. Query count:" $SLOWCOUNT  >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ Etc Configuration Info ############

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Etc Configuration Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Crontab</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
crontab -l   >>$ofile 2>&1 
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">pgAgent</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
ps -ef  | grep pgagent | grep -v "grep" >>$ofile 2>&1 
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Analysis Comments</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"3\" bgcolor=#F6CECE><PRE>....</PRE></TD></TR>">>$ofile 2>&1
echo "</TABLE>">>$ofile 2>&1
echo "This Report is created by OpenSource Business Team.<br>">>$ofile 2>&1
echo "Contact to us: <A href='http://opensource.kt.com'>http://opensource.kt.com</a>">>$ofile 2>&1
echo "</BODY></HTML>">>$ofile 2>&1
echo "Finished...100%"
echo "*********************"
echo "Open up the file in your favourite Web Browser"
rm /tmp/tztz.$DATE.py
exit 0
