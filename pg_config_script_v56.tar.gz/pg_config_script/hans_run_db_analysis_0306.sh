#!/bin/bash

# 마지막 수정일: 2025.03.06
# 하다 말았으니, 하위 내용 추가해서 더 진행해야함
# Analysis Tool for PostgreSQL v3
# Created by OpenSource Team, kt ds.
# Used to determine system information with a single command

#########################################################################
# Set Variable
#########################################################################

SCRIPT_VSERSION=3
DATE=`date +%Y%m%d%H%M`
HOST_NM=`hostname`

# Set variable
PGDATA=`echo $PGDATA`

if [ -z ${PGDATA} ]; then
	echo "asd"
	exit 1
fi

if [ -z ${PGDATA} ]; then
	echo "ERROR! Please set PGDATA."
	exit 1
fi

DB_VERSION=`cat $PGDATA/PG_VERSION`
if [ -z ${DB_VERSION} ]; then
	echo "ERROR! Please set PGDATA. or Check in \$PGDATA\/PG_VERSION file."
	exit 1
fi

CLUSTER=`echo ${PGDATA} | cut -d '/' -f 3`
if [ -z ${CLUSTER} ]; then
	echo "ERROR! Please set PGDATA."
	exit 1
fi


MEM=`cat /proc/meminfo | grep MemTotal | sed -e 's/[^0-9]//g'`
if [ -z ${MEM} ]; then
	echo "ERROR! Please Check MEM."
	exit 1
fi

echo "DB Analysis Tool for PostgreSQL/EDB PAS v${SCRIPT_VSERSION}"
echo "Copyright 2025 OpenSource Team, kt ds."
echo "--------------------------------------------------------------"

echo -n "Input database name: "
read DBNAME

echo -n "Input database port: "
read DBPORT

echo -n "Please input 'enterprisedb' or 'postgres' account password: "
read PGPW

#DBNAME=`echo ${DBNAME} | tr [A-Z] [a-z]`;
#PGPW=`echo ${PGPW} | tr [A-Z] [a-z]`;

if [ -z $DBNAME ]; then
	echo "ERROR! Please input database name."
	exit
elif [ -z $DBPORT ]; then
	echo "ERROR! Please input database port."
	exit
elif [ -z $PGPW ]; then
	echo "ERROR! Please input account password"
	exit
fi;

PGPASSWORD=${PGPW} psql -p ${DBPORT} -A -X -t -p ${DBPORT} -c "select 1" ${DBNAME} >&/dev/null
if [ $? -ne 0 ]; then
	echo "ERROR! Please check database name or port or account password"
	exit;
else
	echo "------------------------------------------"
fi	


#########################################################################
# stasdasd
#########################################################################

cat > /tmp/tztz.$DATE.py  <<EOFF
#!/usr/bin/python
import sys
import re

keycount = {};

for i in re.split("\\|", sys.argv[1]):
        keycount[i] = 0;

try:
    while True:
        s = sys.stdin.readline();
        if not s:
                break;
        r = re.search(sys.argv[1],  s.strip());
        if r:
                keycount[r.group(0)] += 1;
except KeyboardInterrupt:
    sys.stdout.flush()
    pass
for k, v in keycount.items():
 print("%d : %s" % (v,k))
EOFF
chmod 777 /tmp/tztz.$DATE.py


#########################################################################
# Set HTML out file
#########################################################################

# you can edit this to suit your own output location
HTML_OUT_FILE=./analysis_${HOST_NM}_${DATE}.html

#echo "Removing old system info file ($HTML_OUT_FILE)"
export LC_ALL=C

# OS version check
ver=$(uname -r | awk -F- '{print $1}')

# find command
find_sbin_cmd() {
    for base in / /usr/ /usr/local; do
        if [ -e $base/sbin/$1 ]; then
            echo $base/sbin/$1
            exit
        fi
    done
}
FDISK=`which fdisk 2>/dev/null`
LSUSB=`which lsusb 2>/dev/null`
LSPCI=`which lspci 2>/dev/null`
[ -z "$FDISK" ] && FDISK=`find_sbin_cmd fdisk`
[ -z "$LSUSB" ] && LSUSB=`find_sbin_cmd lsusb`
[ -z "$LSPCI" ] && LSPCI=`find_sbin_cmd lspci`







# START HTML
echo "Generating system stats, please wait ... (can take a few minutes on slow systems)"
echo "File generated at $HTML_OUT_FILE on `date` (FORMAT: analysis_HOSTNAME_DATE.html)"

cat > $HTML_OUT_FILE <<EOFF
<HTML>
<head>
	<meta content="text/html; charset=UTF-8" http-equiv="content-type" />
	<title>DB Analysis Info.</title>
	<style type="text/css">
		table { border-collapse:collapse; }
		th, TD { border:1px solid #000000; }
		/* hide checkbox */
		input[type="checkbox"] { display:none; }
		/* toggle style */
		.toggle {
		display:inline-block;
		padding: 2px;
		background-color:#002266;
		color: #ffffff;
		border-radius:2px;
		cursur: pointer;
		margin-top: 5px;
		font-size: 8px;
	}
	/* hide content */
	.content {
		display: none; /* 기본적으로 숨김 */
            	margin-top: 10px;
            	background-color: #F0F0F0;
            	padding: 10px;
	}
	/* checkbox show */
	input[type="checkbox"]:checked + .toggle + .content {
            display: block; /* 체크 시 내용 표시 */
        }
	</style>
</head>
<BODY>
<H1>DB(Postgres/EDB PAS) Analysis Information</H1>
EOFF

echo "Report generated on `date`. <br>">>$HTML_OUT_FILE 2>&1 
echo "Script Version : ${SCRIPT_VSERSION}">>$HTML_OUT_FILE 2>&1 

#########################################################################
# OS System Information
#########################################################################

echo "<TABLE><TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Operating System Information</b></FONT></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Hostname
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Hostname</FONT>" >> $HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle1\"><label class=\"toggle\" for=\"toggle1\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ hostname</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
hostname >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# OS Version
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">OS Version</FONT>" >> $HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle2\"><label class=\"toggle\" for=\"toggle2\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ cat /etc/redhat-release</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
cat /etc/redhat-release >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Kernel
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Kernel</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle3\"><label class=\"toggle\" for=\"toggle3\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ uname -a</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
uname -a >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# CPU Model
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">CPU Model</FONT>" >>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle4\"><label class=\"toggle\" for=\"toggle4\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ grep \"model name\" /proc/cpuinfo | head -1</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
grep "model name" /proc/cpuinfo | head -1  >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# CPU Specification
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">CPU Specification</FONT>" >>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle5\"><label class=\"toggle\" for=\"toggle5\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ lscpu</PRE></DIV>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
lscpu >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Memory (KB)
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Memory (KB)</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle6\"><label class=\"toggle\" for=\"toggle6\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ cat /proc/meminfo | grep MemTotal | sed -e 's/[^0-9]//g'</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
cat /proc/meminfo | grep MemTotal | sed -e 's/[^0-9]//g' >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Filesystem Size
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Filesystem Size</FONT>" >>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle7\"><label class=\"toggle\" for=\"toggle7\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ df -h<BR><BR>$ df -i</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
echo "<b>disk usage(%)</b>" >> $HTML_OUT_FILE 2>&1
df -h >> $HTML_OUT_FILE 2>&1
echo "<b>inode usage(%)</b>" >> $HTML_OUT_FILE 2>&1
df -i >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1


#########################################################################
# Network Information
#########################################################################

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Network Information</b></FONT></TD></TR>" >> $HTML_OUT_FILE 2>&1


# Interface Settings
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Interface Settings</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle8\"><label class=\"toggle\" for=\"toggle8\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ /sbin/ifconfig</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
/sbin/ifconfig >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Hosts
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Hosts</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle9\"><label class=\"toggle\" for=\"toggle9\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ cat /etc/hosts</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
cat /etc/hosts >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1


#########################################################################
# Server Status
#########################################################################

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Server Status Information</b></FONT></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Processor/RAM Usage
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Processor/RAM Usage</FONT>" >> $HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle10\"><label class=\"toggle\" for=\"toggle10\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ top -b -n 1 | sed -n '1,20p'<BR><BR>$ free -m</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
top -b -n 1 | sed -n '1,20p' >> $HTML_OUT_FILE 2>&1
echo "<b>-------------------------------------------------</b>" >> $HTML_OUT_FILE 2>&1
free -m >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Running Postgres Background Processes 
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Running Postgres Background Processes</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle11\"><label class=\"toggle\" for=\"toggle11\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ ps -eHf | grep "/bin/postgres\|/bin/edb-postgres\|process\|VACUUM\|er" | grep -v "grep"</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
ps -eHf | grep "/bin/postgres\|/bin/edb-postgres\|process\|VACUUM\|er" | grep -v "grep" >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1


#########################################################################
# Database Information
#########################################################################

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Database Information</b></FONT></TD></TR>">>$HTML_OUT_FILE 2>&1

# Version
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Version</FONT>" >> $HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle12\"><label class=\"toggle\" for=\"toggle12\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"select version();\" ${DBNAME}</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -c "select version();" ${DBNAME} >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Database List
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Database List</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle13\"><label class=\"toggle\" for=\"toggle13\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"\l+\" ${DBNAME}</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -c "\l+" ${DBNAME} >>$HTML_OUT_FILE 2>&1 >> $HTML_OUT_FILE 2>&1
echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1

# Directory Info
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Directory Info</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle14\"><label class=\"toggle\" for=\"toggle14\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
case "${DB_VERSION}" in 6|7|8|9)
	echo "<PRE>$ ls -l $PGDATA<BR>$ ls -l /archive<BR>$ ls -l /pg_xlog</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
	echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
	ls -l $PGDATA >> $HTML_OUT_FILE 2>&1
	ls -l /pg_xlog >> $HTML_OUT_FILE 2>&1
	ls -l /archive >> $HTML_OUT_FILE 2>&1
	;;
	*)
	echo "<PRE>$ ls -l $PGDATA<BR>$ ls -l /archive<BR>$ ls -l /pg_wal</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
	echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
	ls -l $PGDATA >> $HTML_OUT_FILE 2>&1
	ls -l /pg_wal >> $HTML_OUT_FILE 2>&1
	ls -l /archive >> $HTML_OUT_FILE 2>&1
	;;
esac


# Tablespace Info
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">TableSpace Info.</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle15\"><label class=\"toggle\" for=\"toggle15\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1
#echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1

case "${DB_VERSION}" in 8.4)
	echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"SELECT spcname, pg_get_userbyid(spcowner) AS owner,<BR> CASE WHEN length(spclocation) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') <BR>ELSE spclocation END AS spclocation,<BR> spcacl,<BR>  pg_size_pretty(pg_tablespace_size(spcname)) AS size<BR> FROM pg_tablespace ORDER BY spcname;\" ${DBNAME}" >> $HTML_OUT_FILE 2>&1
	echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
	PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -c "SELECT spcname, pg_get_userbyid(spcowner) AS owner, CASE WHEN length(spclocation) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') ELSE spclocation END AS spclocation, spcacl,  pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;" ${DBNAME} >>$HTML_OUT_FILE 2>&1
	;;
	9.0|9.1)
	echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"SELECT spcname, pg_get_userbyid(spcowner) AS owner,<BR> CASE WHEN length(spclocation) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') <BR>ELSE spclocation END AS spclocation,<BR> spcacl,<BR> spcoptions<BR> , pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;\" ${DBNAME}" >> $HTML_OUT_FILE 2>&1
	echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
	PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -c "SELECT spcname, pg_get_userbyid(spcowner) AS owner, CASE WHEN length(spclocation) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') ELSE spclocation END AS spclocation, spcacl, spcoptions , pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;" ${DBNAME} >> $HTML_OUT_FILE 2>&1
	;;
	*)
	echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"SELECT spcname, pg_get_userbyid(spcowner) AS owner,<BR> CASE WHEN length(pg_tablespace_location(oid)) = 0 THEN (SELECT setting<BR> FROM pg_settings WHERE name='data_directory') ELSE pg_tablespace_location(oid) END AS spclocation,<BR> spcacl,<BR> pg_tablespace_location(oid) as spcoptions,<BR> pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;\" ${DBNAME}" >> $HTML_OUT_FILE 2>&1
	echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
	PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -c "SELECT spcname, pg_get_userbyid(spcowner) AS owner, CASE WHEN length(pg_tablespace_location(oid)) = 0 THEN (SELECT setting FROM pg_settings WHERE name='data_directory') ELSE pg_tablespace_location(oid) END AS spclocation, spcacl, pg_tablespace_location(oid) as spcoptions , pg_size_pretty(pg_tablespace_size(spcname)) AS size FROM pg_tablespace ORDER BY spcname;" ${DBNAME} >>$HTML_OUT_FILE 2>&1
	;;
esac

echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1


# Idle in transaction processes
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Idle in transaction Processes</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle16\"><label class=\"toggle\" for=\"toggle16\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1

case "${DB_VERSION}" in
	8.4|9.0|9.1)
		echo "<PRE>$ ps -eHf | grep \"idle in transaction\" | grep -v \"grep\"</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
		echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
		ps -eHf | grep "idle in transaction" | grep -v "grep" >> $HTML_OUT_FILE 2>&1
		;;

	*)
		echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"select * from pg_stat_activity where state = 'idle in transaction';\" ${DBNAME}</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
		echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
		PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -c "select * from pg_stat_activity where state = 'idle in transaction';" ${DBNAME} >> $HTML_OUT_FILE 2>&1
		;;
esac

echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1


# Long running transaction processes(1 days)
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Long running transaction Processes(1 days)</FONT>">>$HTML_OUT_FILE 2>&1
echo "<input type=\"checkbox\" id=\"toggle17\"><label class=\"toggle\" for=\"toggle17\">SHOW</label><DIV class=\"content\">" >> $HTML_OUT_FILE 2>&1

case "${DB_VERSION}" in
	8.4|9.0|9.1)
		echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"select now(), * from pg_stat_activity where xact_start < now() - interval '1 days';\" ${DBNAME}</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
		echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
		PGPASSWORD={PGPW} psql -p ${DBPORT} -X -c "select now(), * from pg_stat_activity where xact_start < now() - interval '1 days';" ${DBNAME} >> $HTML_OUT_FILE 2>&1
		;;
	*)
		echo "<PRE>$ PGPASSWORD=XXXX psql -p ${DBPORT} -X -c \"select now(), * from pg_stat_activity where state = 'active' and xact_start < now() - interval '1 days';\" ${DBNAME}</PRE></DIV></TD>" >> $HTML_OUT_FILE 2>&1
		echo "<TD valign=top><PRE>" >> $HTML_OUT_FILE 2>&1
		PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -c "select now(), * from pg_stat_activity where state = 'active' and xact_start < now() - interval '1 days';" ${DBNAME} >> $HTML_OUT_FILE 2>&1
		;;

esac

echo "</PRE></TD></TR>" >> $HTML_OUT_FILE 2>&1


#########################################################################
# Connection & Memory Info
#########################################################################

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Connection & Mem Information</b></FONT></TD></TR>">>$HTML_OUT_FILE 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$HTML_OUT_FILE
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$HTML_OUT_FILE
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Setting Value</b></FONT></TD></TD>">>$HTML_OUT_FILE

################
# max_connection 
################

echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">max_connections</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">less than 200</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top>">>$HTML_OUT_FILE 2>&1

MAX_CONN=`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "select setting::int from pg_settings where name='max_connections';" ${DBNAME}`

if [ ${MAX_CONN} -le 200 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "show max_connections;" ${DBNAME}`" >>$HTML_OUT_FILE 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "show max_connections;" ${DBNAME}`" >>$HTML_OUT_FILE 2>&1
fi;
echo "</FONT></TD></TR>">>$HTML_OUT_FILE 2>&1

################################
# superuser_reserved_connections
################################

echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">superuser_reserved_connections</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">3</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top>">>$HTML_OUT_FILE 2>&1

if [ "3" != `PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "show superuser_reserved_connections" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "show superuser_reserved_connections;" ${DBNAME}`" >>$HTML_OUT_FILE 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "show superuser_reserved_connections;" ${DBNAME}`" >>$HTML_OUT_FILE 2>&1
fi;
echo "</FONT></TD></TR>">>$HTML_OUT_FILE 2>&1

################
# shared_buffes 
################

RECO_SHARED_BUFFERS_25=$(echo "$MEM*0.25" | bc | cut -d '.' -f 1)
RECO_SHARED_BUFFERS_50=$(echo "$RECO_SHARED_BUFFERS_25*0.50" | bc | cut -d '.' -f 1)

MIN_SHARED_BUFFERS=$(echo "$RECO_SHARED_BUFFERS_25-$RECO_SHARED_BUFFERS_50" | bc)
MAX_SHARED_BUFFERS=$(echo "$RECO_SHARED_BUFFERS_25+$RECO_SHARED_BUFFERS_50" | bc)

echo "RECO_SHARED_BUFFERS_25 = $RECO_SHARED_BUFFERS_25"
echo "RECO_SHARED_BUFFERS_50 = $RECO_SHARED_BUFFERS_50"
echo "MIN_SHARED_BUFFERS = $MIN_SHARED_BUFFERS"
echo "MAX_SHARED_BUFFERS = $MAX_SHARED_BUFFERS"


current_shared_buffers=`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "select setting::int*8 from pg_settings where name='shared_buffers';" ${DBNAME}`

echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\" title=\"physical Memory * 0.25\">shared_buffers</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">${RECO_SHARED_BUFFERS_25}KB<br>( physical Memory * 0.25 )</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top>">>$HTML_OUT_FILE 2>&1

if [ $current_shared_buffers -ge $MIN_SHARED_BUFFERS ] && [ $set_shared_buffers -le $MAX_SHARED_BUFFERS ]; then
	echo "<FONT>${current_shared_buffers}KB" >>$HTML_OUT_FILE 2>&1
else
	echo "<FONT COLOR=#ff0000>${current_shared_buffers}KB" >>$HTML_OUT_FILE 2>&1
fi;
echo "</FONT></TD></TR>">>$HTML_OUT_FILE 2>&1


################
# work_mem
################

echo "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"

extra_mem=$(echo "$MEM - ($MEM * 0.25)" | bc -l | cut -d '.' -f 1)

reco_work_mem=$(echo "$extra_mem / $MAX_CONN" | bc )

current_work_mem=`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "select setting from pg_settings where name='work_mem';" ${DBNAME}`

half_work_mem=$(echo "${reco_work_mem} * 0.50" | bc | cut -d '.' -f 1)

min_work_mem=$(echo "${reco_work_mem} - ${half_work_mem}" | bc )
max_work_mem=$(echo "${reco_work_mem} + ${half_work_mem}" | bc )


echo "extra_mem = $extra_mem"
echo "reco_work_mem = $reco_work_mem"
echo "current_work_mem = $current_work_mem"
echo "half_work_mem = $half_work_mem"
echo "min_work_mem = $min_work_mem"
echo "max_work_mem = $max_work_mem"


echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\" title=\"(physical Memory -Shared buffer)/connection\">work_mem</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">${WM}KB<br>(physical Memory-Shared buffer)/connection)</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top>">>$HTML_OUT_FILE 2>&1

if [ $current_work_mem -ge $min_work_mem -a $current_work_mem -le $max_work_mem ]; then
	echo "<FONT>${current_work_mem}KB" >>$HTML_OUT_FILE 2>&1
else
	echo "<FONT COLOR=#ff0000>${current_work_mem}KB" >>$HTML_OUT_FILE 2>&1
fi;
echo "</FONT></TD></TR>">>$HTML_OUT_FILE 2>&1




MWM=`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "select setting from pg_settings where name='maintenance_work_mem'"`;

echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\" title=\"work_mem * 1.5\">maintenance_work_mem</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">512MB</FONT></TD>">>$HTML_OUT_FILE 2>&1
echo "<TD valign=top>">>$HTML_OUT_FILE 2>&1

if [ ${MWM} -ge 51200 -a ${MWM} -le 524288 ]; then 
	echo "<FONT>${MWM}KB" >>$HTML_OUT_FILE 2>&1
else
	echo "<FONT COLOR=#ff0000>${MWM}KB" >>$HTML_OUT_FILE 2>&1
fi;
echo "</FONT></TD></TR>">>$HTML_OUT_FILE 2>&1


EDBDT=`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "select setting from pg_settings where name='edb_dynatune';"`
if [ -z ${EDBDT} ]; then
	echo "This is not EDB server. so skip check edb_dynatune"
	echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">edb_dynatune</FONT></TD>">>$HTML_OUT_FILE 2>&1
	echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">99</FONT></TD>">>$HTML_OUT_FILE 2>&1
	echo "<TD valign=top>">>$HTML_OUT_FILE 2>&1
	echo "<FONT>This is not EDB server. so skip check edb_dynatune</FONT></TD></TR>" >> $HTML_OUT_FILE 2>&1
else
	echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">edb_dynatune</FONT></TD>">>$HTML_OUT_FILE 2>&1
	echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">99</FONT></TD>">>$HTML_OUT_FILE 2>&1
	echo "<TD valign=top>">>$HTML_OUT_FILE 2>&1

	if [ ${EDBDT} -le 65 ]; then
		echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "show edb_dynatune;" ${DBNAME}`" >>$HTML_OUT_FILE 2>&1
	else
		echo "<FONT>`PGPASSWORD=${PGPW} psql -p ${DBPORT} -X -t -c "show edb_dynatune;" ${DBNAME}`" >>$HTML_OUT_FILE 2>&1
	fi;
	echo "</FONT></TD></TR>">>$HTML_OUT_FILE 2>&1
fi



############ WAL Info ############
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">WAL Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Setting Value</b></FONT></TD></TD>">>$ofile


echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">Transaction log size</FONT></TD>">>$ofile 

if [ "${DB_VERSION}" == "9.5"  -o "${DB_VERSION}" == "9.6"  -o "${DB_VERSION}" == "10" -o "${DB_VERSION}" == "11"  -o "${DB_VERSION}" == "12"  -o "${DB_VERSION}" == "13" ]; then
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">max_wal_size: 2GB<br>min_wal_size: 2GB</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
echo "max_wal_size:" >>$ofile 2>&1
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show max_wal_size;" ${DBNAME}`<br>" >>$ofile 2>&1
echo "min_wal_size:" >>$ofile 2>&1
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show min_wal_size;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">32~128</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
CPS=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::int from pg_settings where name='checkpoint_segments';" ${DBNAME}`
if [ ${CPS} -ge 32 -a ${CPS} -le 128 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_segments;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_segments;" ${DBNAME}`" >>$ofile 2>&1
fi;
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">checkpoint_timeout</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">5min~15min</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
CPT=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::int from pg_settings where name='checkpoint_timeout';" ${DBNAME}`
if [ ${CPT} -ge 300 -a ${CPT} -le 900 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_timeout;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_timeout;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">checkpoint_completion_target</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">0.5~0.9</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
CCT=`PGPASSWORD=${PGPW} psql -X -t -c "select setting::float*10 from pg_settings where name='checkpoint_completion_target';" ${DBNAME}`
if [ ${CCT} -ge 5 -a ${CCT} -le 9 ]; then 
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_completion_target;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show checkpoint_completion_target;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">wal_buffers</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">16MB</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "16MB" != `PGPASSWORD=${PGPW} psql -X -t -c "show wal_buffers" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_buffers;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_buffers;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
if [ "${DB_VERSION}" != "8.4" ]; then
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">wal_level</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">logical</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "minimal" = `PGPASSWORD=${PGPW} psql -X -t -c "show wal_level" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_level;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_level;" ${DBNAME}`" >>$ofile 2>&1
fi;
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">fsync</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "on" != `PGPASSWORD=${PGPW} psql -X -t -c "show fsync" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show fsync;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show fsync;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">synchronous_commit</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "on" != `PGPASSWORD=${PGPW} psql -X -t -c "show Synchronous_commit" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show Synchronous_commit;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show Synchronous_commit;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">wal_sync_method</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">fdatasync</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "fdatasync" != `PGPASSWORD=${PGPW} psql -X -t -c "show wal_sync_method" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_sync_method;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show wal_sync_method;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">archive_mode</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "on" != `PGPASSWORD=${PGPW} psql -X -t -c "show archive_mode" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show archive_mode;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show archive_mode;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

TMPC=`echo "dd conv=fdatasync bs=256k if=%p of=/archive/temp/%f && \\\mv -f /archive/temp/%f /archive/${CLUSTER}"`
TMPC2=`PGPASSWORD=${PGPW} psql -X -t -c "show archive_command;" ${DBNAME} |sed 's/^ //'`
echo "<TR><TD valign=top TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">archive_command</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "$TMPC" = "$TMPC2" ]; then 
echo "<FONT>${TMPC2}" >>$ofile 2>&1
else
echo "<FONT COLOR=#ff0000>${TMPC2}<br>" >>$ofile 2>&1
echo "<A href='http://opensource.kt.com/db/-/wiki/Main/archive+command'><pre>More Detail. Click Here!!</pre></a>" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1

############ Planner Info ############
echo "Planner Info...70%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Planner Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Existing Value</b></FONT></TD></TD>">>$ofile
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">random_page_cost</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">4</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "4" != `PGPASSWORD=${PGPW} psql -X -t -c "show random_page_cost;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show random_page_cost;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show random_page_cost" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">default_statistics_target</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">100</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1

if [ "100" != `PGPASSWORD=${PGPW} psql -X -t -c "show default_statistics_target;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show default_statistics_target;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show default_statistics_target" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Changed Settings: Need to reset</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "select name, setting,short_desc from pg_settings where setting<>reset_val and name like 'enable_%';" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ AutoVaccum Info ############

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">AutoVaccum Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Parameter Name</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Recommended Value</b></FONT></TD>">>$ofile
echo "<TD valign=top bgcolor=#696969><FONT COLOR=#ffffff size=\"3\">Existing Value</b></FONT></TD></TD>">>$ofile
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">autovacuum</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">on</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "off" = `PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">autovacuum_max_workers</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top bgcolor=#F0F0F0><FONT size=\"3\">5</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top>">>$ofile 2>&1
if [ "5" != `PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum_max_workers;" ${DBNAME}` ]; then 
echo "<FONT COLOR=#ff0000>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum_max_workers;" ${DBNAME}`" >>$ofile 2>&1
else
echo "<FONT>`PGPASSWORD=${PGPW} psql -X -t -c "show autovacuum_max_workers;" ${DBNAME}`" >>$ofile 2>&1
fi;
echo "</FONT></TD></TR>">>$ofile 2>&1
# analyze 대상 객체 출력
PGPASSWORD=${PGPW} psql -X -t -c "select 'analyze ' || a.oid::regclass || ';' from pg_class a left join 
(select starelid, sum(stawidth) as rowsize from pg_statistic group by starelid) b 
on (a.oid = b.starelid) 
where a.relkind in ('r','m') and a.relname <> 'pg_statistic' and (a.reltuples::numeric * b.rowsize) is null;" ${DBNAME} > analyze_list.sql
# analyze 수행
PGPASSWORD=${PGPW} psql -X -f analyze_list.sql ${DBNAME} > analyze_list.log
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Vacuum & autovacuum Information: May need to vacuum </FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT schemaname,
       a.oid::regclass as table_name,
       age(a.relfrozenxid),
       pg_size_pretty(pg_relation_size(relid)) AS relation_size,
       coalesce(last_vacuum::text, 'Never') as last_vacuum,
       coalesce(last_autovacuum::text, 'Never') as last_autovacuum,
       coalesce(last_analyze::text, 'Never') as last_analyze,
       coalesce(last_autoanalyze::text, 'Never') as last_autoanalyze
FROM pg_class a
LEFT JOIN (select relname,relid,last_autovacuum,last_vacuum,last_autoanalyze,last_analyze,schemaname
        from   pg_stat_all_tables
        where  pg_relation_size(relid) > 104857600 ) b ON a.oid = b.relid 
LEFT JOIN (SELECT starelid, sum(stawidth) AS stawidth
                   FROM pg_statistic
                   GROUP BY starelid) c ON a.oid = c.starelid 
WHERE relkind IN ('r', 'm')
AND a.relname <> 'pg_statistic'
AND relpages > 0
and ((( last_autovacuum IS NULL OR last_autovacuum < now() - interval '3 month' ) AND ( last_vacuum IS NULL  OR last_vacuum < now() - interval '3 month' ))
   OR  (( last_autoanalyze IS NULL OR last_analyze < now() - interval '3 month') AND (last_analyze IS NULL OR last_analyze < now() - interval '3 month' )))
and b.schemaname not in ('pg_toast', 'information_schema', 'pg_catalog', 'sys')
ORDER BY 2 desc;" ${DBNAME} >>$ofile 2>&1
echo "<FONT><A href='http://opensource.kt.com/db/-/wiki/Main/Autovacuum+Information'>More Detail. Click Here!!</a></FONT>">>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

# Aging table list
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Aging table list: May need to vacuum</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "select relname as table_name, age(relfrozenxid) from pg_class where age(relfrozenxid) > 200000000 and relkind in ('r','t','m') order by 2 desc;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ Statistics Info ############
echo "Statistics Info...80%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Statistics Information</b></FONT></TD></TR>">>$ofile 2>&1
#echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Cache Hit Rate</FONT></TD>">>$ofile 2>&1
#PGPASSWORD=${PGPW} psql -X -c "SELECT datname,   round(blks_hit*100/(blks_hit+blks_read), 2) AS cache_hit_ratio FROM pg_stat_database WHERE blks_read > 0;" ${DBNAME} >>$ofile 2>&1

#echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Table Cache Hit Rate</FONT></TD>">>$ofile 2>&1
#PGPASSWORD=${PGPW} psql -X -c "SELECT relname,  round(heap_blks_hit*100/(heap_blks_hit+heap_blks_read), 2)  AS cache_hit_ratio FROM pg_statio_user_tables WHERE heap_blks_read > 0 ORDER BY cache_hit_ratio;" ${DBNAME} >>$ofile 2>&1

# DB별 age
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Database Age</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT datname as database, age(datfrozenxid) from pg_database;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Top busy table info(50)</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT n.nspname as schema_name, c.relname as table_name,
           pg_stat_get_live_tuples(c.oid) as rows,
           pg_stat_get_numscans(c.oid) as seqscan,
           pg_stat_get_tuples_returned(c.oid) as returned_rows,
           CASE WHEN coalesce(pg_stat_get_numscans(c.oid),0) = 0
           THEN 0
           ELSE round(coalesce(pg_stat_get_tuples_returned(c.oid),0)/pg_stat_get_numscans(c.oid),1) END AS returned_rows_average,
           sum(coalesce(pg_stat_get_numscans(i.indexrelid),0)) as idxscan, 
           CASE WHEN  pg_stat_get_blocks_fetched(c.oid) = 0
           THEN 0
           ELSE round(((pg_stat_get_blocks_hit(c.oid) * 1.0) / pg_stat_get_blocks_fetched(c.oid)) * 100,2) END AS tab_hit,
           CASE WHEN sum(coalesce(pg_stat_get_blocks_fetched(i.indexrelid),0)) = 0
           THEN 0
           ELSE round(((sum(coalesce(pg_stat_get_blocks_hit(i.indexrelid),0)) * 1.0) / sum(coalesce(pg_stat_get_blocks_fetched(i.indexrelid),0))) * 100, 2) END AS idx_hit
FROM pg_class c
  LEFT JOIN pg_index i ON c.oid = i.indrelid
  LEFT JOIN pg_namespace n ON n.oid = c.relnamespace 
WHERE c.relkind = 'r' and n.nspname not in ('pg_catalog','information_schema','pg_toast','sys','pgagent')
GROUP BY c.oid, n.nspname, c.relname
ORDER BY seqscan desc, rows desc limit 50;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Bloat table: Need to vacuum</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT b.schemaname,
       a.oid::regclass as table_name,
       age(a.relfrozenxid),
       a.relpages * 8::int8 AS relation_size,
       ceil((b.n_live_tup * c.stawidth) * 1.0 / 8192) * 8 AS actual_size,
       int8((a.relpages * 8::int8) / (ceil((b.n_live_tup * c.stawidth) * 1.0 / 8192) * 8)) AS bloating_ratio,
       last_vacuum,
       last_autovacuum
FROM pg_class a
LEFT JOIN pg_stat_all_tables b ON a.oid = b.relid
LEFT JOIN (SELECT starelid, sum(stawidth) AS stawidth FROM pg_statistic GROUP BY starelid) c ON a.oid = c.starelid
WHERE relkind IN ('r', 'm')
AND a.relname <> 'pg_statistic'
AND relpages > 0
and b.n_live_tup > 0
AND int8((a.relpages * 8::int8) / (ceil((b.n_live_tup * c.stawidth) * 1.0 / 8192) * 8)) > 5
ORDER BY 2 desc;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Bloat index: Need to reindex</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT c.schemaname,
       c.relname as table_name,
       a.oid::regclass as index_name,
       a.relpages * 8192::int8 AS index_size,
       ceil(b.keywidth * 1.0 * c.n_live_tup / 7373) * 8192 + 8192 AS actual_size,
       round((a.relpages * 8192::int8 * 1.0) / (ceil(b.keywidth * 1.0 * c.n_live_tup / 7373) * 8192 + 8192), 0) AS bloating_ratio 
FROM pg_class a,(SELECT a.indexrelid, a.indrelid, sum(b.stawidth + 1) + 9 AS keywidth
                                 FROM pg_index a, pg_statistic b
                                 WHERE a.indrelid = b.starelid
                                 AND arraycontains(string_to_array(a.indkey::text, ' '), array[b.staattnum::text])
                                 GROUP BY a.indexrelid, a.indrelid) b,
     pg_stat_all_tables c
WHERE a.oid = b.indexrelid
AND b.indrelid = c.relid
AND round((a.relpages * 8192::int8 * 1.0) / (ceil(b.keywidth * 1.0 * c.n_live_tup / 7373) * 8192 + 8192), 0) > 2 
order by 6 desc;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Unused Index: Need to check</FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "SELECT n.nspname AS schema_name, c.relname as table_name, i.relname AS index_name, pg_indexes_size(indexrelid) as index_size, pg_stat_get_blocks_fetched(i.oid) AS idx_fetched, pg_stat_get_blocks_hit(i.oid) AS idx_blks_hit
   FROM pg_class c
   JOIN pg_index x ON c.oid = x.indrelid
   JOIN pg_class i ON i.oid = x.indexrelid
   LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE c.relkind =  ANY (ARRAY['r'::"char", 't'::"char"])
  and n.nspname not in ('pg_catalog','information_schema','pg_toast','sys','pgagent') and pg_stat_get_blocks_fetched(i.oid) = 0;" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Duplicate indexes: Need to check </FONT></TD>">>$ofile 2>&1
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "with ttt as (
SELECT indrelid, indexrelid::regclass AS idx,
               (indrelid::text ||E'\n'|| indclass::text ||E'\n'|| indkey::text ||E'\n'|| coalesce(indexprs::text, '')||E'\n' || coalesce(indpred::text, '')) AS KEY
        FROM   pg_index)
        select ttt.indrelid::regclass as table_name, array_to_string(array_agg(ttt.idx),',') as index_name from ttt  GROUP BY KEY, table_name
HAVING count(*)>1" ${DBNAME} >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">LOCK Info</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
if [ "${DB_VERSION}" == "13" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type='Lock';" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "12" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type='Lock';" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "11" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type='Lock';" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "10" ]; then 
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type is not null and backend_xid is not null;" ${DBNAME} >>$ofile 2>&1
elif [ "${DB_VERSION}" == "9.6" ]; then
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where wait_event_type is not null;" ${DBNAME} >>$ofile 2>&1
else
PGPASSWORD=${PGPW} psql -X -c "select * from pg_stat_activity where waiting='t';" ${DBNAME} >>$ofile 2>&1
fi;
echo "</PRE></TD></TR>">>$ofile 2>&1
############ Log Info ############
echo "Log Info...90%"
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Log Information</b></FONT></TD></TR>">>$ofile 2>&1

if [ "${DB_VERSION}" == "10" -o "${DB_VERSION}" == "11" -o "${DB_VERSION}" == "12" -o "${DB_VERSION}" == "13" ]; then 
SLOWCOUNT=`find $PGDATA/log/ -type f -mtime -1 | xargs grep duration | egrep -v 'BEGIN|COMMIT|ROLLBACK' | cut -d ' ' -f 9 | sort -rn | wc -l`
else
SLOWCOUNT=`find $PGDATA/pg_log/ -type f -mtime -1 | xargs grep duration | egrep -v 'BEGIN|COMMIT|ROLLBACK' | cut -d ' ' -f 9 | sort -rn | wc -l`
fi;

echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Changed Settings: Need to reset</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
PGPASSWORD=${PGPW} psql -X -c "select name, setting,short_desc from pg_settings where setting<>reset_val and name like 'log_rotation%';" ${DBNAME} >>$ofile 2>&1
SLOWTIME=`PGPASSWORD=${PGPW} psql -X -t -c "show log_min_duration_statement"`
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">ERROR Scan Information</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
if [ "${DB_VERSION}" == "10" -o "${DB_VERSION}" == "11" -o "${DB_VERSION}" == "12" -o "${DB_VERSION}" == "13" ]; then 
find $PGDATA/log/ -mtime -90 -name "*.log" -exec egrep "ERROR:|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed" {} \; | /tmp/tztz.$DATE.py  "ERROR|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed">>$ofile 2>&1
else
find $PGDATA/pg_log/ -mtime -90 -name "*.log" -exec egrep "ERROR:|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed" {} \; | /tmp/tztz.$DATE.py  "ERROR|FATAL|PANIC|INTERNAL ERROR|DATA CORRUPTED|INDEX CORRUPTED|another server process exited abnormally|logger shutting down|out of memory|database system was interrupted|database system is shut down|database system was not properly shut down|automatic recovery|checkpoints are occurring too frequently|remaining connection slots are reserved for non-replication superuser connections|too many clients already|current transaction is aborted|transaction canceling statement due to user request|OCI call failed|must be vacuumed within|database is not accepting commands to avoid wraparound data loss in database|invalid byte sequence for encoding|duplicate key value violates unique constraint|syntax error|does not exist|already exists|deadlock detected|invalid input syntax for type|value too long for type character varying|missing FROM-clause entry for table|ambiguous|unterminated quoted string at|must appear in the GROUP BY clause or be used in an aggregate function|failed to find conversion function from unknown to character varying|more than one row returned by a subquery used as an expression|each UNION query must have the same number of columns at character|UNION types timestamp without time zone and character varying cannot be matched at character|date format not recognized|multiple primary keys for table|could not send data to client|unexpected EOF on client connection with an open transaction|pgstat wait timeout|password authentication failed">>$ofile 2>&1
fi;
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">slow query running time in 24 hours</FONT></TD>" >>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
echo "Slow query time is${SLOWTIME}. Query count:" $SLOWCOUNT  >>$ofile 2>&1
echo "</PRE></TD></TR>">>$ofile 2>&1

############ Etc Configuration Info ############

echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Etc Configuration Information</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">Crontab</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
crontab -l   >>$ofile 2>&1 
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"2\" bgcolor=#F0F0F0><FONT size=\"3\">pgAgent</FONT></TD>">>$ofile 2>&1 
echo "<TD valign=top><PRE>">>$ofile 2>&1
ps -ef  | grep pgagent | grep -v "grep" >>$ofile 2>&1 
echo "</PRE></TD></TR>">>$ofile 2>&1
echo "<TR><TD colspan=\"3\" bgcolor=#002266><FONT COLOR=#ffffff size=\"5\">Analysis Comments</b></FONT></TD></TR>">>$ofile 2>&1
echo "<TR><TD valign=top colspan=\"3\" bgcolor=#F6CECE><PRE>....</PRE></TD></TR>">>$ofile 2>&1
echo "</TABLE>">>$ofile 2>&1
echo "This Report is created by OpenSource Business Team.<br>">>$ofile 2>&1
echo "Contact to us: <A href='http://opensource.kt.com'>http://opensource.kt.com</a>">>$ofile 2>&1
echo "</BODY></HTML>">>$ofile 2>&1
echo "Finished...100%"
echo "*********************"
echo "Open up the file in your favourite Web Browser"
rm /tmp/tztz.$DATE.py
exit 0
