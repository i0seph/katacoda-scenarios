#!/bin/sh
# Install for EDB PAS v1.1 for 12 ver
# Created by OpenSource Team, KTDS.
#yum install -y ed libicu gcc gcc-c++ make clang gettext tcl-devel zlib-devel readline-devel perl-devel python-devel pam-devel openldap-devel openssl-devel libxml2-devel libxslt-devel uuid-devel libicu-devel perl-ExtUtils-Embed libedit-devel
#yum install -y vi vim ed shadow-utils glibc-devel gcc gcc-c++ rsync whereis passwd net-tools hostname /sbin/ip wget clang readline-devel zlib-devel gettext make bison flex perl-ExtUtils-MakeMaker perl-ExtUtils-Embed curl krb5-devel libicu-devel openssl-devel pam-devel libxml2-devel openldap-devel uuid-devel python-devel libxslt-devel libedit-devel

# Script Cotributer Hans.choi for Opensource Team (2024-05-02 ~ ...)

# 해당 스크립트는 root 유저로 수행 가능하며 아래와 같은 경로가 존재해야 수행할 수 있다.
# /postgres
# /data
# /pg_wal or /pg_xlog
# /archive

# 설치 관련 로그는 /postgres 디렉토리에 이력을 남긴다.
# 필수 파일 3가지가 반드시 /postgres 디렉토리에 존재해야한다.
# 1. 해당 스크립트 (postgresql_auto_install_scripts)
# 2. 설치 바이너리 (postgresql-xxxxxxx.tar.gz)
# 3. 환경 설정 스크립트 (pg_config_script)

###################################################################################################
# Check path for auto install scripts [1]
###################################################################################################
LOGDATE=`date +%Y-%m-%d\ %H:%M:%S`
if [ ! -d /postgres ]; then
    echo "[$LOGDATE][ERROR]Can't find \"/postgres\" directory !! So can't logging & installing [1]"
    exit 1;
else
    echo "[$LOGDATE][LOG] Check server environment" > /postgres/PG_AUTO_INSTALL.LOG
fi

###################################################################################################
# Check Arguments [2]
###################################################################################################
if [ $# -ne 3 ]; then
	echo "[$LOGDATE][NOTICE] Usage: "\$0" CLUSTER_NAME "\$1" DB_NAME "\$2" SCHEMA_NAME [2-1]" >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][NOTICE] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
	exit 1;

elif [ $# -eq 3 ]; then	
	CLUSTERNAME=$1;
	DBNAME=$2;
	SCHEMANAME=$3;
	echo "[$LOGDATE][LOG] CLUSTER_NAME : ${CLUSTERNAME}, DB_NAME : ${DBNAME}, SCHEMA_NAME : {SCHEMANAME} [2-2]" >> /postgres/PG_AUTO_INSTALL.LOG
fi

###################################################################################################
# Check Install OS User & OS Version [3]
###################################################################################################
current_user=`whoami`
if [ "$current_user" != "root" ]; then
    echo "[$LOGDATE][ERROR] $current_user is invalid user to install [3-1]"  >> /postgres/PG_AUTO_INSTALL.LOG
    echo "[$LOGDATE][NOTICE] Please login by root [3-1]"  >> /postgres/PG_AUTO_INSTALL.LOG
    echo "[$LOGDATE][NOTICE] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
    exit 1;
fi

SYSVER=`cat /etc/redhat-release | awk -F '.' '{print $1}'| awk '{print $NF}'`
if [ -z $SYSVER ]; then
    echo "[$LOGDATE][ERROR] Can't read system OS version [3-2]"  >> /postgres/PG_AUTO_INSTALL.LOG
    echo "[$LOGDATE][NOTICE] \"Check Install OS User & OS Version Section.\" [3-2]"  >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][ERROR] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
    exit 1;
else
    echo "[$LOGDATE][LOG] OS version : ${SYSVER}" >> /postgres/PG_AUTO_INSTALL.LOG
fi

###################################################################################################
# Check Current Directory Path [4]
###################################################################################################
current_dir=`pwd`
if [ "$current_dir" != "/postgres" ]; then
    cd /postgres
    if [ $? != 0 ]; then
        echo "[$LOGDATE][ERROR] Can't find /postgres! [4]" >> /postgres/PG_AUTO_INSTALL.LOG
		echo "[$LOGDATE][NOTICE] Check \"Check Current Directory Path Section.\" [4]" >> /postgres/PG_AUTO_INSTALL
		echo "[$LOGDATE][ERROR] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
        exit 1;
    fi
fi

###################################################################################################
# Check Install File & Config File [5]
###################################################################################################
INSTALLFILE=`ls | grep postgresql | grep tar.gz | sort | tail -n 1 `
if [ -z $INSTALLFILE ]; then
	echo "[$LOGDATE][ERROR] Install file doesn't exist [5-1]" >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][NOTICE] Please check install file or \"Check Install File & Config File Section.\" [5-1]" >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][ERROR] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
	exit 1;
fi

CONFIGFILE=`ls | grep pg_config_script | grep tar.gz`
if [ -z $CONFIGFILE ]; then
	echo "[$LOGDATE][ERROR] Configuration file doesn't exist [5-2]" >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][NOTICE] Please check configuration file or \"Check Install File & Config File Section.\" [5-2]" >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][ERROR] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
	exit 1;
fi

###################################################################################################
# Check PostgreSQL version [6]
###################################################################################################
MAJORVERSION=`echo $INSTALLFILE|awk -F '.' {'print $1'}|awk -F '-' {'print $NF'}`

if [ "${MAJORVERSION}" = "" ]; then
	echo "[$LOGDATE][ERROR] Can't read major version in INSTALLFILE [6-1]" >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][NOTICE] Check \"Check PostgreSQL version Section.\" [6-1]" >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][ERROR] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
	exit 1;
fi

if [ "$MAJORVERSION" -ge "90" ]; then
	MAJORVERSION=`echo $MAJORVERSION|awk {'printf"%.1f\n",$1/10'}`
	
	WL=xlog
	echo "[$LOGDATE][NOTICE] Major version : ${MAJORVERSION}. so using pg_${WL} [6-2]" >> /postgres/PG_AUTO_INSTALL.LOG

else
	WL=wal 
	echo "[$LOGDATE][NOTICE] Major version : ${MAJORVERSION}. so using pg_${WL} [6-3]" >> /postgres/PG_AUTO_INSTALL.LOG
fi

###################################################################################################
# Check Mount Points [7]
###################################################################################################
#MOUNT_DIR1=`mount | grep '/postgres'`
#MOUNT_DIR2=`mount | grep '/data'`
#MOUNT_DIR3=`mount | grep /pg_${WL}`
#MOUNT_DIR4=`mount | grep '/archive'`

# 꼭 마운트 되어 있는 디스크를 확인해야하나? 가 아니라면, 
# 특정 디렉토리에 마운트가 된 상태라면 디렉토리 존재 여부만 확인하면 될거 같아서 일단 이렇게 작성
if [ ! -d /postgres ]; then
	echo "[$LOGDATE][ERROR] Can't find \"/postgres\" directory [7-1]" >> /postgres/PG_AUTO_INSTALL.LOG
	exit 1;
fi

if [ ! -d /data ]; then
	echo "[$LOGDATE][ERROR] Can't find \"/data\" directory [7-2]" >> /postgres/PG_AUTO_INSTALL.LOG
	exit 1;
fi

if [ ! -d /pg_${WL} ]; then
	echo "[$LOGDATE][ERROR] Can't find \"/pg_${WL}\" directory [7-3]" >> /postgres/PG_AUTO_INSTALL.LOG
	exit 1;
fi

if [ ! -d /archive ]; then
	echo "[$LOGDATE][ERROR] Can't find \"/archive\" directory [7-4]" >> /postgres/PG_AUTO_INSTALL.LOG
	exit 1;
fi

###################################################################################################
# Create User & Set File Authority And Access [8]
###################################################################################################
# history | tail -n 2 | head -n 1 | awk '{ for (i=2; i<=NF; i++) printf "%s ", $i; printf "\n"; }'

function command_checking() {
	echo "[$LOGDATE][ERROR] Some task is not execute complete. Check Task num -> "$1 >> /postgres/PG_AUTO_INSTALL.LOG
	echo "[$LOGDATE][ERROR] Check '/postgres/PG_AUTO_INSTALL.LOG' file"
	exit 1;
}

useradd -d /postgres/${MAJORVERSION} postgres || command_checking "[8-1]"
echo "[$LOGDATE][LOG] \"postgres\" OS user created"  >> /postgres/PG_AUTO_INSTALL.LOG

chown postgres:postgres $INSTALLFILE $CONFIGFILE || command_checking "[8-2]"
chmod 755 $INSTALLFILE $CONFIGFILE || command_checking "[8-3]"
echo "[$LOGDATE][LOG] Chown & chmod task to \"postgres\" for ${INSTALLFILE} & ${CONFIGFILE}"  >> /postgres/PG_AUTO_INSTALL.LOG

mkdir /data/${CLUSTERNAME} || command_checking "[8-4]"
mkdir /pg_${WL}/${CLUSTERNAME} || command_checking "[8-5]"
mkdir /archive/${CLUSTERNAME} || command_checking "[8-6]"
echo "[$LOGDATE][LOG] Make directories in /data/${CLUSTERNAME}, /pg_${WL}/${CLUSTERNAME}, /archive/${CLUSTERNAME} "  >> /postgres/PG_AUTO_INSTALL.LOG

chown -R postgres:postgres /postgres /data /pg_${WL} /archive || command_checking "[8-7]"
chmod 700 /data /pg_${WL} /archive || command_checking "[8-8]"
echo "[$LOGDATE][LOG] Chown & chmod task to \"postgres\" for /postgres, /pg_${WL}, /archive, /data"  >> /postgres/PG_AUTO_INSTALL.LOG

###################################################################################################
# PostgreSQL File Install & Initdb [9]
# EDB PPAS Auto Install 은? 상업 라이센스로 인해 자동 설치는 지원하지 않음.
###################################################################################################
echo "[$LOGDATE][LOG] PostgreSQL Database PostgreSQL File Install & Initdb starting..."  >> /postgres/PG_AUTO_INSTALL.LOG

su - postgres -c "cd /postgres;tar -xvf ${INSTALLFILE};" || command_checking "[9]"

#rpm -Uvh /postgres/${MAJORVERSION}/libicu*${MAJORVERSION}*.x86_64.rpm

if [ "${MAJORVERSION}" -ge "11" ] && [ "$SYSVER" = "7" ]; then
	rpm -Uvh /postgres/${MAJORVERSION}/llvm7.0-libs-7.0.1-4.el7.x86_64.rpm
fi

su - postgres -c "/postgres/${MAJORVERSION}/bin/initdb -D /data/${CLUSTERNAME} -X /pg_${WL}/${CLUSTERNAME} -E UTF8 --no-locale -k;"
if [ $? != 0 ]; then
	echo "[$LOGDATE][ERROR] Initdb command failed! [9-1]" >> /postgres/PG_AUTO_INSTALL.LOG
	exit 1;
fi

###################################################################################################
# Set Postgres .bash_profile [10]
###################################################################################################
echo "[$LOGDATE][LOG] Setting postgres user .bash_profile configuration"  >> /postgres/PG_AUTO_INSTALL.LOG

cp /etc/skel/.bash* /postgres/${MAJORVERSION} || command_checking [10-1]
chown postgres:postgres /postgres/${MAJORVERSION}/.bash* || command_checking [10-2]
su - postgres -c "
cat >> ~/.bash_profile << EOF

########## start postgres .bash_profile
alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'
export PATH=$PATH:/postgres/${MAJORVERSION}/bin
export PGHOST=127.0.0.1
export PGDATA=/data/${CLUSTERNAME}
export PGDATABASE=postgres
export PGUSER=postgres
export PGPORT=5432
export PGLOCALEDIR=/postgres/${MAJORVERSION}/share/locale
export HISTTIMEFORMAT='%Y-%m-%d %H:%M:%S '
########## end of postgres .bash_profile
EOF

source ~/.bash_profile
" || command_checking [10-3]

echo "[$LOGDATE][LOG] postgres user .bash_profile configuration DONE."  >> /postgres/PG_AUTO_INSTALL.LOG

###################################################################################################
# Default Objects & PostgreSQL Config Configuration [11]
###################################################################################################
echo "[$LOGDATE][LOG] Setting Default objects & PostgreSQL configuration"  >> /postgres/PG_AUTO_INSTALL.LOG

mkdir /postgres/${MAJORVERSION}/kt_extension || command_checking [11-1]
cp /postgres/$CONFIGFILE /postgres/${MAJORVERSION}/kt_extension/ || command_checking [11-2]

cd /postgres/${MAJORVERSION}/kt_extension/ || command_checking [11-3]
tar -xvf $CONFIGFILE || command_checking [11-4]

chown -R postgres:postgres /postgres/${MAJORVERSION}/kt_extension || command_checking [11-5]
chmod 700 /postgres/${MAJORVERSION}/kt_extension/pg_config_script/* || command_checking [11-6]
cd /postgres/${MAJORVERSION}/kt_extension/pg_config_script || command_checking [11-7]

su - postgres -c "pg_ctl -w -D /data/${CLUSTERNAME} start;" || command_checking [11-8]

su - postgres -c "cd /postgres/${MAJORVERSION}/kt_extension/pg_config_script;sh pg_and_pas_conf_change_v2.sh ${CLUSTERNAME}" || command_checking [11-9]

su - postgres -c "cd /postgres/${MAJORVERSION}/kt_extension/pg_config_script;sh 00_after_initdb.sh ${DBNAME} ${SCHEMANAME};" || command_checking [11-10]

echo "[$LOGDATE][LOG] Default objects & PostgreSQL configuration DONE."  >> /postgres/PG_AUTO_INSTALL.LOG

su - postgres -c "pg_ctl -w -mf -D /data/${CLUSTERNAME} stop;" || command_checking [11-11]
su - postgres -c "pg_ctl -w -D /data/${CLUSTERNAME} start;" || command_checking [11-12]

echo "[$LOGDATE][LOG] PostgreSQL auto installation complete!!!" >> /postgres/PG_AUTO_INSTALL.LOG
echo "[$LOGDATE][LOG] PostgreSQL auto installation complete!!!"
