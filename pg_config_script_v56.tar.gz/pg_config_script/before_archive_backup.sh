#######################################################
## 서버별 설정 부분
#######################################################

## 아카이브 디렉터리
ARCH_DIR=/archive/preorder

LOG_FILE_NAME=/data/DBA/backup_result/arch_backup_`date +%Y%m%d%H%M`.log

#######################################################
## 백업 수행 부분
#######################################################

ls -t $ARCH_DIR | tail -n +10  > /data/DBA/backup_result/db_before_archive_list

date >> $LOG_FILE_NAME
echo "Start archive backup" >> $LOG_FILE_NAME
