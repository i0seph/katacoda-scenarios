
###### after backup! ###############

##archive directory
ARCH_DIR=/archive/preorder

##  
LOG_DIR=/data/DBA/backup_result

#backup part

LOG_FILE_NAME=/data/DBA/backup_result/arch_backup_`date +%Y%m%d%H%M`.log

TIME_NOW=`date +%Y%m%d_%H:%M`

if [ "$SMEXIT" = "0" ]
then
        cd $ARCH_DIR
        while read FILES
        do
             rm -f $FILES
        done < /data/DBA/backup_result/db_before_archive_list
        mv /data/DBA/backup_result/db_before_archive_list $LOG_DIR/archive_complete_list_$TIME_NOW.log
fi

date >> $LOG_FILE_NAME
echo "End archive backup" >> $LOG_FILE_NAME
